#!/bin/bash
# Copyright (c) 2021 Qumulo, Inc. All rights reserved.
#
# NOTICE: All information and intellectual property contained herein is the
# confidential property of Qumulo, Inc. Reproduction or dissemination of the
# information or intellectual property contained herein is strictly forbidden,
# unless separate prior written permission has been obtained from Qumulo, Inc.

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

# This script adds the desired static route(s).
cp "$SCRIPT_DIR/static_route.sh" /history/

# Run-anywhere platforms run a service inside the container that invokes /history/static_route.sh
if [ -e /config/run_anywhere ]; then
    /history/static_route.sh now
    exit 0
fi

# This service runs static_route.sh every time the qcore container (re)starts.
cp "$SCRIPT_DIR/qumulo-static-route.service" /etc/systemd/system/

# Runs static_route.sh on every boot.
# Also enables the qumulo-static-route service.
cp "$SCRIPT_DIR/static_route_cron" /etc/cron.d/

# Ensure that the workaround files are copied to their proper locations on all
# subsequent boots.
if [ -e /run/qumulo/qcore_container ]; then
    container_root=/run/qumulo/qcore_container/root/overlay
else
    container_root=/container_roots/qcore
fi
cp "$container_root/opt/qumulo/lib/persist_config_manifest" /config/
cat >> /config/persist_config_manifest <<EOF
etc/systemd/system/qumulo-static-route.service
etc/cron.d/static_route_cron
EOF
qsh -c /opt/qumulo/qinternal/host_config/persist_config.py

# Ensure that the workaround works for *current* boot.
systemctl enable qumulo-static-route.service
/history/static_route.sh now

